Usage
=============

A python script for converting MSCOCO json file format to PASCAL VOC xml file format  in **Object Detection**.

```
python coco2voc.py --json_path path/to/data.json  --output path/to/save/xml_files 
```


type `python coco2voc.py -h` for more details.